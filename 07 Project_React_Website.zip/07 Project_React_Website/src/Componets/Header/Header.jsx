import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
// import Footers from './img/logo-2.png';
import Footers from '../imgs/logo-2.png';
  function Header() {return (
<Navbar expand="lg" className="bg-white border- border-b-2 border-indigo-10 ...">
<Container>
   <Navbar.Brand href="#home">
   <img src={Footers}
     className="mr-3 h-12" alt="Logo" /> 
   </Navbar.Brand > 
   <Navbar.Collapse id="basic-navbar-nav">
    
     <Nav className="ms-auto">     
         <Nav.Link  className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 focus:outline-none"
         href="Home">Home</Nav.Link>
         <Nav.Link   className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 focus:outline-none"
         href="About">About</Nav.Link>
         <Nav.Link   className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 focus:outline-none"
         href="Contact">Contact</Nav.Link>
         <Nav.Link   className="text-gray-800 hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 focus:outline-none"
         href="Github"> Github</Nav.Link>
         <button   className="text-white hover:bg-gray-400  bg-red-500  focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 focus:outline-none"
         href="Contect"  >Login</button>
    </Nav>
   </Navbar.Collapse>
 </Container>
</Navbar>
);}
export default Header


