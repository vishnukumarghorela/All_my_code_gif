
const Contact = () => {
  return (
    <div className="max-w-md mx-auto bg-gray-100 p-8 border rounded-md mt-10 mb-5 shadow-lg">
      <h2 className="text-2xl font-semibold mb-6 text-center pb-4 text-gray-800">Contact Form</h2>
      <form action="#" method="post" className="space-y-4">
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">Username</label>
          <input type="text" id="username" name="username" className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your username" />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="Email">Email</label>
          <input type="email" id="Email" name="Email" className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your email" />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="Contact">Contact</label>
          <input type="text" id="Contact" name="Contact" className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your contact number" />
        </div>
        <button type="submit" className="w-full bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">Submit</button>
      </form>
    </div>
  );
}

export default Contact;












//    // import formpik  from './images/banner-png.png' 
//    import Button from 'react-bootstrap/Button';
//    import Form from 'react-bootstrap/Form';
//    import InputGroup from 'react-bootstrap/InputGroup';
//    // import { Form } from "react-router-dom"
   
   
   
//    const Contect = () =>{
//        return(
           
//            <>   
           


              
   
//            <div className='form bg-gray-400 w-96 ... '>     
   
//      <div className='formimg'></div>
//      <div className='form1'>
//        <div className='form11'>   
//           <Form>     
//           <h1 className='Enquiry'></h1> 
//          <Form.Group className="mb-3" controlId="formGroupPassword">
//            <Form.Label>Your Name</Form.Label>
//            <InputGroup className="mb-3">
//            <InputGroup.Text id="basic-addon1">@</InputGroup.Text>
//            <Form.Control
//              placeholder="Username"
//              aria-label="Username" 
//              aria-describedby="basic-addon1"/>
//          </InputGroup>    
//          </Form.Group>
//          <Form.Group className="mb-3" controlId="formGroupEmail">
//            <Form.Label>Email address</Form.Label>
//            <InputGroup className="mb-3">
//            <InputGroup.Text id="basic-addon1"> <i className="fa-solid fa-user" width="20"></i>
//    </InputGroup.Text>
//            <Form.Control
//              placeholder="Enter Your Email "
//              aria-label="Username"
//              aria-describedby="basic-addon1"
//            />
//          </InputGroup> 
   
//          </Form.Group>
//          <Form.Group className="mb-3" controlId="formGroupPassword">
//            <Form.Label>You Address</Form.Label>
//            <InputGroup className="mb-3">
//            <InputGroup.Text id="basic-addon1">        
//            <i className="fa-solid fa-square-envelope" width="20"></i> 
//        </InputGroup.Text>
//            <Form.Control
//              placeholder="Enter Your Address"
//              aria-label="Username"
//              aria-describedby="basic-addon1"
//            />
//          </InputGroup> 
   
//          </Form.Group>
//          <Form.Group className="mb-3" controlId="formGroupPassword">
//            <Form.Label >Your Contect No</Form.Label>
//            <InputGroup className="mb-3">
//            <InputGroup.Text id="basic-addon1">
//            <i className="fa-solid fa-phone" width="20"></i>
   
//            </InputGroup.Text>
//            <Form.Control
//              placeholder="Enter Your Contect No"
//              aria-label="Username"
//              aria-describedby="basic-addon1"
//              />
//          </InputGroup> 
//          </Form.Group>
//          <Form.Group className="mb-4" controlId="exampleForm.ControlTextarea1">
//            <Form.Label>Message</Form.Label>      
//            <Form.Control as="textarea" rows={3} 
//                      placeholder="Enter Your Contect No" />
   
//          </Form.Group>
//          <Button variant="primary">Submit</Button> 
   
//        </Form>  </div>    
//      </div>
//      </div>  
           
           
//            </>
  
  
//   )
// }

// export default Contect