import { Routes, Route } from "react-router-dom";
// import { useState } from 'react'

import './App.css'
import Footer from './Componets/Footer/Footer'
import Header from './Componets/Header/Header'
import Home from './Componets/Home/Home'
import Contact from "./Componets/Contect";
import Github from "./Componets/Github";
import About from "./Componets/About";
// import Dummy from "./Componets/dummy";
function App() {
  // const [count, setCount] = useState(0)

  return (
    
      <>
      {/* <Dummy/> */}
      <Header/>
      <Routes > 
               <Route path="Home" element={<Home />} />
               <Route path="About" element={<About/>} />
               
               {/* <Route path="About" element={<About />} /> */}
                {/* <Route path='vishnu'/> */}
               {/* </Route> */}
               <Route path="About/vishnuGhorela" element={<About />} >
                <Route path='vishnu'/>
               </Route>
               <Route path="Contact" element={<Contact  names="hello props" />} />
               <Route path="Github" element={<Github names="hello props" />} />
       </Routes >
        
      <Footer/>
      
    </>
  )
}

export default App
