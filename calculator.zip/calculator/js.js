const Number = (num) => document.getElementById('display').value += num;
const clearDisplay = () => document.getElementById('display').value = '';
const calculate = () => document.getElementById('display').value = eval(document.getElementById('display').value);
