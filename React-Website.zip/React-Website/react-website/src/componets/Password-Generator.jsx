

import { useState, useCallback, useEffect, useRef } from "react";

function Project4() {
  const [length, setLength] = useState(8);
  const [Nunbers, setN] = useState(false);
  const [charaA, setChar] = useState(false);
  const [password, setPassword] = useState("");

// useRef hooks
// useRef hooks
const passwoedref =useRef(null)

// useRef hooks

// Callback hooks


  const NumberAllowed = true; // Placeholder for NumberAllowed, replace it with your logic if needed

  const pawsgnratr = useCallback(() => {
    let pass = "";
    let str = "ABCDEFGHIJabcdefghij";
    if (NumberAllowed) str += "0123456789";
    if (charaA) str += "-=-=-=-=/.';][{}'";
    for (let i = 1; i < length; i++) {
      let char = Math.floor(Math.random() * str.length + 1);
      pass += str.charAt(char);
    }
    setPassword(pass);
  }, [length, Nunbers, charaA, NumberAllowed]);

  useEffect(() => {
    pawsgnratr();
  }, [length, Nunbers, charaA, pawsgnratr]);
// Callback hooks
  
const copypasword =useCallback(()=>{
  window.navigator.clipboard.writeText(password)
  passwoedref.current?.select()
  
},[password])


  
  return (
    <>
      {/* <div>Project4</div> */}
      <div className="  flex justify-center items-center   bg-slate-400">
      <div className="  w-1/2    max-w-auto shadow-md rounded-lg px-4 my-8 text-orange-500 bg-gray-700" >
        <h1 className="text-4xl text-center text-white">Password-Generator</h1>
        <div className="flex shadow rounded-lg overflow-hidden mb-4">
          <input
            type="text"
            value={password}
            className="outline-none w-full py-1 px-3"
            placeholder="Password"
            readOnly
            ref={passwoedref}
          />
          <button onClick={copypasword} className="outline-none bg-blue-700 text-white px-3 py-3 py-0.5 shrink-0">
            Copy
          </button>
        </div>

        <div className="flex text-sm gap-x-2">
          <div className="flex items-center gap-x-1">
            <input
              type="range"
              min={6}
              max={100}
              value={length}
              className="cursor-pointer"
              onChange={(e) => {
                setLength(e.target.value);
              }}
            />
            <label>Length: {length}</label>
          </div>
          <div className="flex items-center gap-x-1">
            <input
              type="checkbox"
              defaultChecked={Nunbers}
              id="numberinput"
              onChange={() => {
                setN((prev) => !prev);
              }}
            />
            <label htmlFor="numberinput">Number</label>
          </div>
          <div className="flex items-center gap-x-1">
            <input
              type="checkbox"
              defaultChecked={charaA}
              id="characterinput"
              onChange={() => {
                setChar((prev) => !prev);
              }}
            />
            <label htmlFor="characterinput">Characters</label>
          </div>
        </div>
      </div>
      </div>
    </>
  );
}

export default Project4;










