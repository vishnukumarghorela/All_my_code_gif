import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
// import NavDropdown from 'react-bootstrap/NavDropdown';


function Nave() {
  return (
    <Navbar expand="lg" className="bg-info   ">
      <Container>
        <Navbar.Brand href="#hom">React-Bootstrap</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            {/* UseReducer */}
            
{/*             
            <NavDropdown title="Props-tailwind-css" id="navbarScrollingDropdown">
              <NavDropdown.Item href="Project2">Project2</NavDropdown.Item>
            </NavDropdown> */}
            
            {/* <NavDropdown title="Password-Generator" id="navbarScrollingDropdown">
              <NavDropdown.Item href="Project4">Project4</NavDropdown.Item>
            </NavDropdown> */}
            {/* <NavDropdown title="click-change-colors" id="navbarScrollingDropdown">
              <NavDropdown.Item href="Project3">Project3</NavDropdown.Item>
            </NavDropdown> */}
            {/* <NavDropdown title="Cruncyconvtr" id="navbarScrollingDropdown">
              <NavDropdown.Item href="Cruncyconvtr">Cruncyconvtr</NavDropdown.Item>
            </NavDropdown> */}
            {/* <NavDropdown title="Home" id="navbarScrollingDropdown"> */}
              {/* <NavDropdown.Item href="Header">Header</NavDropdown.Item>
              <NavDropdown.Item href="User">User</NavDropdown.Item>
              <NavDropdown.Item href="Footer">Footer</NavDropdown.Item> */}
            {/* </NavDropdown> */}
           
            <Nav.Link href="Home">Home</Nav.Link>
            <Nav.Link href="Counter">Counter</Nav.Link>
            <Nav.Link href="Api">ApiDummy</Nav.Link>

            {/* <Nav.Link href="Project2">Props_tailwind-css</Nav.Link> */}
            <Nav.Link href="Project4">Password-Generator</Nav.Link>
            <Nav.Link href="Colors_change">click-change-colors</Nav.Link>
          
            
           
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Nave;




