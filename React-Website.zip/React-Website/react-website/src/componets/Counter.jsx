import { useState } from "react";

function Counter() {
  const [text, setText] = useState(0);

  const handleIncrement = () => {
    if (text < 20) setText(text + 1);
  };

  const handleDecrement = () => {
    if (text > 0) setText(text - 1);
  };

  return (
    <>
      <h1 className="text-center bg-info mt-5 p-4">Vite Project</h1>
      <h2 className="text-center my-4 text-2xl">Counter: {text}</h2>

      <div className="flex justify-center space-x-4">
        <button
          onClick={handleIncrement}
          className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-700"
        >
          + Add
        </button>
        <button
          onClick={handleDecrement}
          className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700"
        >
          - Remove
        </button>
      </div>
    </>
  );
}

export default Counter;
