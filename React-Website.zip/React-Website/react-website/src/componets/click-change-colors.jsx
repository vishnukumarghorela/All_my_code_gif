// import React, { useState } from 'react'

import { useState } from "react"
import Container from "react-bootstrap/esm/Container"

function Colors_change() {
    const [color,setcolors]=useState("olive")
    function hello(){
        setcolors("red")

    }
  return (
    <Container>
        <div className="  max-h-full  w-full h-sereen   duration-200 mb-5 "  
    style={{backgroundColor:color , height:"600px"}}>Project3
    
    <div className=" flex flex-wrap justify-center bottom-12 inset-x-0 px-2">
    
    <div className=" flex flex-wrap justify-center gap-3 shadow-lg bg-white px-3 py-2 rounded-xl">
   
   <button onClick={hello} className="outline-none px-4 py-1 rounded-full text-white shadow-lg "
   style={{backgroundColor:"red"}} >red1</button>
   <button onClick={()=>setcolors("blue")} className="outline-none px-4 py-1 rounded-full text-white shadow-lg "
   style={{backgroundColor:"blue"}} >red</button>
   <button onClick={()=>setcolors("green")} className="outline-none px-4 py-1 rounded-full text-white shadow-lg "
   style={{backgroundColor:"green"}} >red</button>
   <button onClick={()=>setcolors("blue")} className="outline-none px-4 py-1 rounded-full text-white shadow-lg "
   style={{backgroundColor:"blue"}}
   >red</button>
    </div>
    </div> 
    </div>

    </Container>

  )
}

export default Colors_change