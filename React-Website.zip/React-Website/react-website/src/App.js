import React from 'react';
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import Nave2 from './componets/Nave2';
import Counter from './componets/Counter';
import Api from './componets/Api';
import Colors_change from './componets/click-change-colors';
import Project4 from './componets/Password-Generator'
// import Project2 from './componets/Props-tailwind-cssr'
import { Routes, Route } from "react-router-dom";




function App() {
  return (
    <>
      <Nave2/>

      <Routes>
        <Route>
        <Route path="Counter" element={<Counter />} />
        <Route path="Api" element={<Api />} />
        <Route path="Colors_change" element={<Colors_change />} />
        <Route path="Project4" element={<Project4 />} />
        {/* <Route path="Project2" element={<Project2 />} /> */}

        
       

        </Route>
      </Routes>
      
      
      
      App
    </>
  );
}

export default App;

