import './App.css'
import Dummy from './Compocet/Dummy'

function App() {

  
  return (
    <>     
    <Dummy/> 
    
   
    </>
  )
}

export default App 


































// // import React from 'react';
// import './App.css';
// import Login from './Compocet/Login';
// import Profile from './Compocet/Profile';
// import UseContextProvider from './Compocet/UsecontextProvider';

// function App() {
//   return (
//     <>
//       <UseContextProvider>
//         <h1 className=' bg-slate-500 py-4'>Context API </h1>
//         <Login />
//         <Profile />
//       </UseContextProvider>
//     </>
//   );
// }

// export default App;