import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

function Navebar() {
  return (

    // --------------------------------
    <Navbar expand="lg" className="bg-body-tertiar bg-info  mb-5 ">
      <Container fluid>
        <Navbar.Brand href="#">Hooks Project</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto m-5 my-lg-0 bg-info text-warning"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            {/* MAIN POINT------< */}
            {/*             
            <Nav.Link href="A">A</Nav.Link>
            <Nav.Link href="B">B</Nav.Link>
            <Nav.Link href="C">C</Nav.Link>
            <Nav.Link href="D">D</Nav.Link> */}


            {/* MAIN POINT------< */}
            {/* UseeState */}
            <NavDropdown title="UseeState" id="navbarScrollingDropdown">
              <NavDropdown.Item href="Counter_inc">Counter_inc</NavDropdown.Item>
              <NavDropdown.Item href="Counter4">Counter4</NavDropdown.Item>
              {/* <NavDropdown.Item href="Counters2">Counters2</NavDropdown.Item> */}
              {/* <NavDropdown.Item href="Counters3">Counters3</NavDropdown.Item> */}
            </NavDropdown> 
            {/* UseeState */}



            {/* Useeffect */}
            <NavDropdown title="Useeffect" id="navbarScrollingDropdown">
              <NavDropdown.Item href="Ueseffects">Ueseffects</NavDropdown.Item>
            </NavDropdown>
            {/* Useeffect */}



            {/* Usecontext */}

            <NavDropdown title="Usecontext" id="navbarScrollingDropdown">
              <NavDropdown.Item href="A">A</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="B">
                B
              </NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="C">
                C
              </NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="D">
                D
              </NavDropdown.Item>
              {/* <NavDropdown.Divider /> */}
            </NavDropdown>
            {/* Usecontext */}



            {/* UseReducer */}
            <NavDropdown title="UseReducer" id="navbarScrollingDropdown">
              <NavDropdown.Item href="UseReducer">UseReducer</NavDropdown.Item>
              <NavDropdown.Item href="useReducerproject2">useReducerproject2</NavDropdown.Item>
              <NavDropdown.Item href="UseReducerproject3">UseReducerproject3</NavDropdown.Item>
            </NavDropdown>
            {/* UseReducer */}
            {/* UseReducer */}
            <NavDropdown title="Clickcomponet" id="navbarScrollingDropdown">
              <NavDropdown.Item href="Clickcomponet">Clickcomponet</NavDropdown.Item>
              <NavDropdown.Item href="State">State</NavDropdown.Item>
              <NavDropdown.Item href="Todoaap">Todoaap</NavDropdown.Item>
              <NavDropdown.Item href="useCallbackhooks">useCallbackhooks</NavDropdown.Item>
            
            </NavDropdown>
            {/* UseReducer */}
            {/* useCallbackhooks */}
            <NavDropdown title="useCallbackhooks" id="navbarScrollingDropdown">              
              <NavDropdown.Item href="useCallbackhooks">useCallbackhooks</NavDropdown.Item>            
            </NavDropdown>
            {/* useCallbackhooks */}
            {/* UseMemo */}
            <NavDropdown title="UseMemo" id="navbarScrollingDropdown">              
              <NavDropdown.Item href="UseMemo">UseMemo</NavDropdown.Item>            
              <NavDropdown.Item href="Anil1">Anil1</NavDropdown.Item>            
            </NavDropdown>
            {/* UseMemo */}
           


          </Nav>
         
            <Button variant="success">Search</Button>
          {/* </Form> */}
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Navebar;