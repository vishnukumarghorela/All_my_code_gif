import React from 'react'
import C from './C'
function B() {
  return (
    <div> B
        <h1>sd,sd </h1>
        <C /> 
    </div>
   
  )
}

export default B