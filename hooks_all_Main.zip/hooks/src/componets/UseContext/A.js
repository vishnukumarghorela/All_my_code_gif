import React, { createContext } from 'react'
import D from './D'

const FirstName = createContext()
const LastName = createContext()

function A( props) { 
    
  return (
    <div> welcom 
    <FirstName.Provider  value={"Ram"}>
    <LastName.Provider value={"sayam"}>
        <D /> 
    </LastName.Provider>
    </FirstName.Provider>
    </div>
    )} 

export default A 
export {FirstName ,LastName}

