

import React, { useContext } from 'react'
import { LastName, FirstName } from './A'

function D() {
    const firstName = useContext(FirstName)
   
    const lastName = useContext(LastName)
  return (
    <div className='bg-warning '>
        useContext Success <br/>
            {lastName} <br/>
            {firstName} 
            

    </div>
  )
}

export default D 

