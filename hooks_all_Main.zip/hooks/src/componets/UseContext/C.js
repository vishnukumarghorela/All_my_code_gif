import React from 'react'
import D from './D'


function C() {
  return (
    <div>vishnu
        <D />
    </div>
  )
}

export default C