
//  ----------------- (1)-----------------------

import React, { useReducer } from 'react'
const increment = 0;
const reducer = (State, action) => {
  switch (action) {
    case "increment":
      return State + 1
    case "decrement":
      return State - 1
    default:
      return State;
  }
}
function UseReducerproject2() {
  const [count, dispatch] = useReducer(reducer, increment)
  return (
    <>
      <div>useReducer Hooks {count}</div>
      <button onClick={() => dispatch("increment")}>inc</button>
      <button onClick={() => dispatch("decrement")}>dec</button>

    </>)
}
export default UseReducerproject2