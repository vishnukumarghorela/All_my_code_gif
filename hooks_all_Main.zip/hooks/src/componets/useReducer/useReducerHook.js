import React, { useReducer, useState } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import '../useReducer/useReducerHook/';


const themes = {
  // red: { background: 'white', color: 'red' },
  // light: { background: 'white', color: 'grey' },
  // dark: { background: 'white', color: 'white' },
};

const ThemeContext = React.createContext();
function ComponentWhith() {
  return <div className='bg-info sss'>ComponentWhith</div>;
}
function useReducerHook() {
  const [theme, setTheme] = useState(themes.light);
  // const [component, setComponent] = useState([<ComponentWhith key={0} />]);
  const reducer = (state, action) => {
    switch (action.type) {
      case 'ADD':  
        return [...state, <ComponentWhith key={state.length} />];

      case 'REMOVE': 
        return [...state].slice(0, -1); 
    }
  };
  const [state, dispatch] = useReducer(reducer, []);
  const AddComponent = () => {
    dispatch({ type: 'ADD' });
  };
  const RemoveComponent = () => {
    dispatch({ type: 'REMOVE' });
  };

  return (
    <>
      <ThemeContext.Provider value={theme}>
        <div className="App  bg-dark ">
          {/* App */}
          {/* <button onClick={() => setTheme(themes.red)}>Red</button>
          <button onClick={() => setTheme(themes.dark)}>Dark</button>
          <button onClick={() => setTheme(themes.light)}>Light</button>
          <br />
          <br /> */}
          <button onClick={AddComponent}>Add</button>
          <button onClick={RemoveComponent}>Remove</button>
          {state.map((c) => c)}
        </div>
      </ThemeContext.Provider>
    </>
  );
}

export default useReducerHook;





