




//  ----------------- (2)---------------------------------------------------------------
import React, {useReducer } from 'react'

const initiaState =5;

const reducer =( State ,action)=>{
  console.log(State , action)
  return State ;
}
const UseReducerproject3 = ()=> {
  const[state,dispatch] = useReducer(reducer , initiaState);
  return (
<>
<div>UseReducer Hook   <br/> Ans Console</div>
<p>{state}</p>
<button onClick={()=>dispatch({type : "increment"})}>inc</button>
<button onClick={()=>dispatch({type : "decrement"})}>dec</button>
</>
 )
}
export default UseReducerproject3 
