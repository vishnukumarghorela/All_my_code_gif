// -------------------------------------------------------------State --State-----------------------------------------------

import React from 'react'

function State(props) {
    // let data ="stateproject"
    
    function change (){

        // data ="hello ji"
        
        alert(' State And props successful')
    }    
  return (
    <>
 
 <div style={{backgroundColor:"skyblue ",margin: 10 ,textAlign:'center'}}>
 <p>Name {props.name}</p>
 <p>Email- {props.Email}</p>
 <button onClick={change}>click</button>
 </div>
   
    </>
   )
 }

 export default State 


// -------------------------------------------------------------class compnents-----------------------------------------------

// import React from 'react'

// function State() {
//   {

//     return (
//       <div>State-and-classcomponenta</div>
//     )

//   }
 
// }

// export default State