import React, { useState, useCallback } from 'react';

const UseCallbackhooks = () => {
 
    
  const [count, setCount] = useState(0);
  
  const handleClickWithCallback = useCallback(() => {
    console.log('Button clicked with useCallback');
    setCount(count + "vishnu ", 1,<br/> );
  }, [count]); 
  
  return (
    <div>
      <p>Count: {count }</p>
      <button onClick={handleClickWithCallback}>
        Click with useCallback
      </button>
    </div>
  );
};

export default UseCallbackhooks;
