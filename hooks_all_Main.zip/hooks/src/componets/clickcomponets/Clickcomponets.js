import React from 'react'

function Clickcomponet() {

  function handel (){
    alert("wlecome")
  }
  return (
    <>  
    
    <div className='text-info  m-2 bg-dark   text-center '>Clickcomponet</div>
     <div className='App'>
  <h1> hello </h1>
  <button  on onClick={handel}>Click me</button>
     </div>
    
    
    </>
  )
}

export default Clickcomponet
