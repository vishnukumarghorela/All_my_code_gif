import React, { useState } from 'react';
// import './App.css';

function Todoaap() {
  const [text, settext] = useState([]);
  const [Input, setInput] = useState('');

  const addTask = () => {
    if (Input.trim() !== '') {
      settext([...text, Input]);
      setInput('');
    }
  };

  const deleteTask = (index) => {
    const newtext = [...text];
    newtext.splice(index, 1);
    settext(newtext);
  };

  return (
    <div className="App">
      <h1>ToDo App</h1> 
     
      <div>
        <input
          type="text"
          value={Input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter your items"
        />
        <button onClick={addTask}>Add items</button>
      </div>
      <div id="task-list">
        {text.map((task, index) => (
          <div key={index} className="task-item">
            <span>{task}</span>
            <button style={{backgroundColor: "red"}} onClick={() => deleteTask(index)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Todoaap;
