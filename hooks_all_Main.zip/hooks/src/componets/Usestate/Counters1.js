import './App.css'
// import Counter1  from'./componet/cuonter'

function Counters1() {


  let counter =""

  const addvalue = () =>{
    // console.log("clicked", Math.random());   //1
    console.log("clicked", counter);           
    counter = counter + 1
  }  
  return (
    <>    
{/* <Counter1/> */} 
    <h1 > helo veet </h1>     
    <h2 > counter value {counter}</h2>  
    <br/>     
        <button onClick={addvalue} >add value </button>  
        <button>remove value</button>   
    

    </>
  )
}

export default Counters1 














// import React, { useReducer, useState ,useReducer } from 'react'



// const themes = {
//   red: { background: 'white', color: 'red' },
//   light: { background: 'white', color: 'grey' },
//   dark: { background: 'white', color: 'white' },
// }
// function useReducerHook() {
//   const [theme, setThem] = useState(theme.light)

//   const [component, setcomponent] = useState([<ComponentWhithHooks></ComponentWhithHooks> ]);
  
//   const reducer = ( state, action)=>{
//     switch(action.type){
//       case 'ADD'
//       return [...state,<ComponentWhithHooks></ComponentWhithHooks> ]
//       break;

//       case 'REMOVE'
//       return [...state].slice(0,-1)    

//     }
    
//   }
//   const [state,dispatch]= useReducer(reducer,[])
  
//   const AddComponent = () => {
//     const allcomponents = [...components]
//     allcomponents.push(<ComponentWhithHooks></ComponentWhithHooks> )
//     setcomponent(allcomponents)
//   }
//   const RemoveComponent = () => {
//     const allcomponents = [...components]
//     allcomponents.pop()
//     setcomponent(allcomponents)

//   }
//   return (
//     <>
//       <ThemeContext.Provider value={theme}>

//       <div className="App">
//         App
//         <button onClick={(setThem(theme.red))}>Red</button>
//         <button onClick={(setThem(theme.dark))}>dark</button>
//         <button onClick={(setThem(theme.light))}>light</button>
//         <br /><br />
//         <button onClick={(AddComponent())}>Add</button>
//         <button onClick={(RemoveComponent())}>remove</button>

//         {
//           state.map(c => c)
//         }
//         {/* <ComponentWhithHooks></ComponentWhithHooks> */}
//         {/* <ComponentWhithClass></ComponentWhithClass> */}

//       </div>

//       </ThemeContext.Provider>
//     </>
//   )
// }

// export default useReducerHook


