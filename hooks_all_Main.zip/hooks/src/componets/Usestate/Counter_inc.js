import React, { useState } from 'react'
import Button from 'react-bootstrap/esm/Button'

function Counter_inc() {
    let [counter, setcounter] = useState(0)

    const addvalue = () => {
        if (counter < 20) {
            setcounter(counter + 1)
        }
    }
    const Remove = () => {
        if (counter > 0) {
            setcounter(counter - 1)
        }

    }
    return (
        <>

            <div className='text-center '> <h1 > Usestate hooks </h1>
                <h2 > Counter Value (-,+)</h2>
                <h3 >  Value {counter}</h3>
                <br />

                <Button onClick={addvalue} variant="success">+ Add Value </Button>

                <Button onClick={Remove} variant="danger">- Remove Value</Button>

            </div>

        </>
    )
}

export default Counter_inc