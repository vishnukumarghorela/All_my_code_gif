import { Routes, Route } from "react-router-dom";
import './App.css';
import A from './componets/UseContext/A';
import B from './componets/UseContext/B';
import C from './componets/UseContext/C';
import D from './componets/UseContext/D';
// import UseReducer from'./copm2/useReducer Hook';
import UseReducer from './componets/useReducer/useReducerHook';
import Navebar from "./componets/Navebaar";
import Ueseffects from "./componets/Useeffect/ueseffect";
import Counter_inc from "./componets/Usestate/Counter_inc";
import Counter4 from "./componets/Usestate/Counter4";
import UseReducerproject2 from "./componets/useReducer/useReducerproject2";
import UseReducerproject3 from "./componets/useReducer/UseReducerproject3";
import State from "./componets/clickcomponets/State-and-classcomponenta";
import Todoaap from "./componets/clickcomponets/Todoaap";
import Clickcomponet from "./componets/clickcomponets/Clickcomponets";
import UseCallbackhooks from './componets/clickcomponets/UseCallbackhooks';
import UseMemo from "./componets/clickcomponets/UseMemo";
import Anil1 from "./componets/anilsidhu/anil1";





function App() {
  return (
    < >          useContext                    
      <Navebar />
      {/* <Anil1/> */}
      <Routes > 
        <Route path="A" element={<A />} />
        <Route path="B" element={<B />} />
        <Route path="C" element={<C />} />
        <Route path="D" element={<D />} />
        <Route path="Ueseffects" element={<Ueseffects/>} />
        <Route path="UseReducer" element={<UseReducer/>} />
        <Route path="Counter_inc" element={<Counter_inc/>} />
        <Route path="Counter4" element={<Counter4/>} />
        <Route path="UseReducerproject2" element={<UseReducerproject2/>} />
        <Route path="UseReducerproject3" element={<UseReducerproject3/>} />
        <Route path="Clickcomponet" element={<Clickcomponet/>} />
        <Route path="State" element={<State   name={'click conmonent props'} Email={"Vishnughorela@.com"}/>} />
        {/* <Route path="Todoaap" element={<Todoaap/>} /> */}
        <Route path="UseCallbackhooks" element={<UseCallbackhooks/>} />
        <Route path="UseMemo" element={<UseMemo/>} />
        <Route path="Anil1" element={<Anil1/>} />
      </Routes>
    </>
  );
}
export default App
