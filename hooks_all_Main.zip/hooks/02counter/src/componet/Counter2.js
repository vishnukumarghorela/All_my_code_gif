import './App.css'
// import Counter1  from'./componet/cuonter'

function Counters2() {


  let counter =""

  const addvalue = () =>{
    // console.log("clicked", Math.random());   //1
    console.log("clicked", counter);           //2  +1+1
    counter = counter + 1
  }  
  return (
    <>    
{/* <Counter1/> */} 
    <h1 > helo veet </h1>     
    <h2 > counter value {counter}</h2>  
    <br/>     
        <button onClick={addvalue} >add value </button>  
        <button>remove value</button>   
    

    </>
  )
}

export default Counters2 
