// import { useState, useEffect } from 'react';
// // import './App.css'


// function Ueseffects() {
//     // useEffect(()=>{
//     //   alert('welcome to useeffect hooks working')

//     // })   

//     const [text, settext] = useState([])

//     useEffect(() => {
//         fetch('https://5fc1a1c9cb4d020016fe6b07.mockapi.io/api/v1/products' + text)
//             .then(text.json())
//             .then(json => settext(json))
//         console.log('bAJKS')
//     })
//     return (
//         <>
//             <div>
//                 <button onClick={() => settext('hello')}>hello</button>

//                 <ul>
//                     {items && items.map(item => {
//                         return <li key={item.id}>{item.id}</li>
//                     })}

//                 </ul>
//             </div>
//         </>
//     )
// }

// export default Ueseffects