import { useState } from 'react';
import './App.css'


function Counters3() {
  let [counter , setcounter ]= useState (0)

  const addvalue =()=>{
    if(counter < 20){
      setcounter(counter + 1)
    }
  }
  const Remove =()=>{
    if(counter > 0){
      setcounter(counter -1) 
    }
    
  }
  return (
    <>    
    <h1 > Usestate hooks </h1>     
    <h2 > Counter value (-,+)</h2>     
    <h3 > counter value {counter}</h3>  
    <br/>     
        <button onClick={addvalue} >add value </button>  
        <button onClick={Remove} >remove value</button>   
    

    </>
  )
}

export default Counters3 






























// export default App;

// import React, { useState, useEffect } from 'react';

// function  App () {
//   const [count, setCount] = useState(0);
//   const handle =()=>{
//     if(count < 20)
//     setCount (count+1)
//   }
//   const handle1 =()=>{
//     if(count > 0)
//     setCount (count-1)
//   }


//   useEffect(() => {

//     document.title = `You clicked ${count} times`;
//   });

//   return (
//     <div>
//       <p>You clicked {count} times</p>
      
      
//       <button onClick={handle1}> Click me</button>
//       <button onClick={handle}> Click me</button>
//     </div>
//   );
// }
// export default App;