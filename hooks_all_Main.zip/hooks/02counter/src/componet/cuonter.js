import './App.css'

function Counter1() {

  let counter =15

  const addvalue = () =>{
    console.log("clicked", Math.random());
  }
  
  return (
    <>    
    <h1 > helo veet </h1>     
    <h2 > counter value {counter}</h2>  
    <br/>     
        <button onClick={addvalue} >add value </button>  
        <button>remove value</button>   
    
    </>
  )
}

export default Counter1 
