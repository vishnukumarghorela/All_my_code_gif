import{ useState , useEffect } from 'react';
// import './App.css'


function Ueseffects() {
    useEffect(()=>{
        alert('stop')
      })

  // let [text , settext ]= useState('0')
  const [text , settext ]= useState("post")
  
  const handel =()=>{
    settext('hello')

  }
  const handel1 =()=>{
    settext('change')

  }
 
  return (
    <>

    <div>
        <button onClick={()=>settext('hello')}>hello</button>
        <button onClick={()=>settext('vishnu')}>vishnu</button>
        <button onClick={()=>settext('kumar')}>kumar</button>
        <button onClick={()=>settext('ghorela')} >ghorela</button>
        <h1> {text}</h1>
        <br/>
        <button  onClick={handel}>ghorela</button>
        <button  onClick={handel1}>chang</button>

        <h1> {text}</h1>
        <h1 value={text}> </h1>

     </div>
        </>
  )
}

export default Ueseffects