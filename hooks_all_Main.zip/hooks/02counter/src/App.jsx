// import{ useState , useEffect } from 'react';
import './App.css'
// import UserContext from './context/context'
import UserContextProvider from './context/contexts'
import Login from './contextcomponets.js/Login'
import Profile from './contextcomponets.js/Profile'


function Ueseffects() {
 
  return ( 
    <>
    <div>
      <UserContextProvider>
        <h1>UserContext</h1>

        <Login />
        {/* <UserContext /> */}
        <Profile />
      </UserContextProvider>

      
        {/* <button>contect</button> */}
       

     </div>
        </>
          )
}

export default Ueseffects