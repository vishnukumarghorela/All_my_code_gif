import {useState} from "react";
import UserContext from "./context";



const UserContextProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    return (
        <UserContext.Provider value={{ user, setUser }}>
  \
        </UserContext.Provider>
    );
};

export default UserContextProvider;
