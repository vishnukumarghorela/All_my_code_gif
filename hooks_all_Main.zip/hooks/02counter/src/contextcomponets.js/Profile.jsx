import react,{ useContext } from "react";
import UserContext from "../context/context";

function Profile() {     
  const { user } = useContext(UserContext);

  if (!user) return <div>Please Login</div>;
 
  return <div>Welcome vishnu {user.username}</div>;    
 
}

export default Profile; 






